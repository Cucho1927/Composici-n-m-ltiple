import org.junit.Test;
import static org.junit.Assert.*;

public class CarroTest {

    @Test
    public void testCrearCarro() {
        Motor motor = new Motor(2.0);
        Chasis chasis = new Chasis(TipoChasis.MONOCASCO);
        Carroceria carroceria = new Carroceria(TipoCarroceria.TUBULAR, "rojo");

        Llanta[] llantas = new Llanta[4];
        for (int i = 0; i < 4; i++) {
            llantas[i] = new Llanta("Goodyear", 25, 20, 15);
        }

        Asiento asientoConductor = new Asiento("Cuero", true);
        Asiento asientoAcompanante = new Asiento("Cuero", true);
        Asiento asientoTrasero = new Asiento("Tela", false);

        Carro carro = new Carro(motor, chasis, carroceria, llantas, asientoConductor, asientoAcompanante, asientoTrasero);

        assertNotNull(carro);
    }

    @Test
    public void testToString() {
        Motor motor = new Motor(2.0);
        Chasis chasis = new Chasis(TipoChasis.MONOCASCO);
        Carroceria carroceria = new Carroceria(TipoCarroceria.TUBULAR, "rojo");

        Llanta[] llantas = new Llanta[4];
        for (int i = 0; i < 4; i++) {
            llantas[i] = new Llanta("Goodyear", 25, 20, 15);
        }

        Asiento asientoConductor = new Asiento("Cuero", true);
        Asiento asientoAcompanante = new Asiento("Cuero", true);
        Asiento asientoTrasero = new Asiento("Tela", false);

        Carro carro = new Carro(motor, chasis, carroceria, llantas, asientoConductor, asientoAcompanante, asientoTrasero);

        // Modificamos ligeramente la representación esperada
        String expected = "Carro\n" +
                "Motor: Motor [volumen=2.0 litros]\n" +
                "Chasis: Chasis [tipo=MONOCASCO]\n" +
                "Carroceria: Carroceria [tipo=TUBULAR, color=azul]\n" + // Cambio el color esperado a "azul"
                "Llantas:\n" +
                "  Llanta 1: Llanta [marca=Goodyear, diametroRin=25 pulgadas, altura=20 pulgadas, anchura=15 pulgadas]\n" +
                "  Llanta 2: Llanta [marca=Goodyear, diametroRin=25 pulgadas, altura=20 pulgadas, anchura=15 pulgadas]\n" +
                "  Llanta 3: Llanta [marca=Goodyear, diametroRin=25 pulgadas, altura=20 pulgadas, anchura=15 pulgadas]\n" +
                "  Llanta 4: Llanta [marca=Goodyear, diametroRin=25 pulgadas, altura=20 pulgadas, anchura=15 pulgadas]\n" +
                "Asiento del Conductor: Asiento [material=Cuero, tieneFunda=Sí]\n" +
                "Asiento del Acompañante: Asiento [material=Cuero, tieneFunda=Sí]\n" +
                "Asiento Trasero: Asiento [material=Tela, tieneFunda=No]\n";

        assertEquals(expected, carro.toString());
    }
}
