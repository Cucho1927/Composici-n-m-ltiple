enum TipoChasis {
    INDEPENDIENTE,
    MONOCASCO
}

enum TipoCarroceria {
    INDEPENDIENTE,
    AUTOPORTANTE,
    TUBULAR
}

class Motor {
    private double volumen;

    public Motor(double volumen) {
        this.volumen = volumen;
    }

    @Override
    public String toString() {
        return "Motor [volumen=" + volumen + " litros]";
    }
}

class Chasis {
    private TipoChasis tipo;

    public Chasis(TipoChasis tipo) {
        this.tipo = tipo;
    }

    @Override
    public String toString() {
        return "Chasis [tipo=" + tipo + "]";
    }
}

class Carroceria {
    private TipoCarroceria tipo;
    private String color;

    public Carroceria(TipoCarroceria tipo, String color) {
        this.tipo = tipo;
        this.color = color;
    }

    @Override
    public String toString() {
        return "Carroceria [tipo=" + tipo + ", color=" + color + "]";
    }
}

class Llanta {
    private String marca;
    private int diametroRin;
    private int altura;
    private int anchura;

    public Llanta(String marca, int diametroRin, int altura, int anchura) {
        this.marca = marca;
        this.diametroRin = diametroRin;
        this.altura = altura;
        this.anchura = anchura;
    }

    @Override
    public String toString() {
        return "Llanta [marca=" + marca + ", diametroRin=" + diametroRin + " pulgadas, altura=" + altura + " pulgadas, anchura=" + anchura + " pulgadas]";
    }
}

class Asiento {
    private String material;
    private boolean tieneFunda;

    public Asiento(String material, boolean tieneFunda) {
        this.material = material;
        this.tieneFunda = tieneFunda;
    }

    @Override
    public String toString() {
        return "Asiento [material=" + material + ", tieneFunda=" + (tieneFunda ? "Sí" : "No") + "]";
    }
}

class Carro {
    private Motor motor;
    private Chasis chasis;
    private Carroceria carroceria;
    private Llanta[] llantas;
    private Asiento asientoConductor;
    private Asiento asientoAcompanante;
    private Asiento asientoTrasero;

    public Carro(Motor motor, Chasis chasis, Carroceria carroceria, Llanta[] llantas, Asiento asientoConductor, Asiento asientoAcompanante, Asiento asientoTrasero) {
        this.motor = motor;
        this.chasis = chasis;
        this.carroceria = carroceria;
        this.llantas = llantas;
        this.asientoConductor = asientoConductor;
        this.asientoAcompanante = asientoAcompanante;
        this.asientoTrasero = asientoTrasero;
    }

    @Override
    public String toString() {
        StringBuilder builder = new StringBuilder();
        builder.append("Carro\n");
        builder.append("Motor: ").append(motor).append("\n");
        builder.append("Chasis: ").append(chasis).append("\n");
        builder.append("Carroceria: ").append(carroceria).append("\n");
        builder.append("Llantas:\n");
        for (int i = 0; i < llantas.length; i++) {
            builder.append("  Llanta ").append(i + 1).append(": ").append(llantas[i]).append("\n");
        }
        builder.append("Asiento del Conductor: ").append(asientoConductor).append("\n");
        builder.append("Asiento del Acompañante: ").append(asientoAcompanante).append("\n");
        builder.append("Asiento Trasero: ").append(asientoTrasero).append("\n");
        return builder.toString();
    }
}

public class Main {
    public static void main(String[] args) {
        Motor motor = new Motor(2.0);

    
        Chasis chasis = new Chasis(TipoChasis.MONOCASCO);

        Carroceria carroceria = new Carroceria(TipoCarroceria.TUBULAR, "rojo");

        
        Llanta[] llantas = new Llanta[4];
        for (int i = 0; i < 4; i++) {
            llantas[i] = new Llanta("Goodyear", 25, 20, 15);
        }

    
        Asiento asientoConductor = new Asiento("Cuero", true);
        Asiento asientoAcompanante = new Asiento("Cuero", true);
        Asiento asientoTrasero = new Asiento("Tela", false);

        
        Carro carro = new Carro(motor, chasis, carroceria, llantas, asientoConductor, asientoAcompanante, asientoTrasero);

        
        System.out.println(carro);
    }
}
